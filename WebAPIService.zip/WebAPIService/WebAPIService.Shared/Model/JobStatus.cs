﻿namespace WebAPIService.Shared.Model
{
    public enum JobStatus
    {
        Pending,
        Completed,    
        Failed
    }
}
